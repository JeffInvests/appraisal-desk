# Appraisal Desk

Internal pipeline and UAD 3.6 workfile tool for a Texas residential appraiser (proof of concept).

- Lead intake: manual, pasted text/email (parsed), or a simulated customer for demos
- Pipeline with deadlines, status rules, call log, search and filters
- Per-file workfile: subject and scope, MLS CSV import, comp grid with adjustment helpers, UAD 3.6 readiness checks
- Exports: audit report, data sheet (JSON), comp grid (CSV), contact vCard
- Reports: earned vs. collected revenue, win rate, turnaround, on-time delivery, lead-source performance, follow-up list,
  receivables with aging, USPAP disclosure and workfile-retention tracking, accountant CSV export

## Run locally
```
pip install -r requirements.txt
python -m streamlit run appraisal_desk.py
```
Data is stored in `appraisal_desk.db` next to the script (SQLite). Use the sidebar button to download backups.

## Password (optional)
Set `app_password` in `.streamlit/secrets.toml` (see the `.example` file). If it is not set, the app is open.

## Notes
- Proof of concept. Use simulated data only on any hosted copy.
- Streamlit Community Cloud storage is ephemeral: the database resets when the app restarts or redeploys.
- The JSON export is a working data sheet, not a UCDP/MISMO XML submission.
